package com.billiardbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        fun add(v: View) { root.addView(v) }
        add(TextView(this).apply { text = "BilliardBot"; textSize = 26f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, (12 * d).toInt(), 0, (12 * d).toInt()) }
        add(status)
        fun button(t: String, f: () -> Unit) = add(Button(this).apply { text = t; setOnClickListener { f() } })
        button("۱) اجازه نمایش روی برنامه‌های دیگر") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("۲) روشن کردن سرویس دسترسی‌پذیری") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("۳) شروع (ضبط صفحه + دکمه‌های شناور)") {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 7)
        }
        add(TextView(this).apply {
            textSize = 14f; setPadding(0, (16 * d).toInt(), 0, 0)
            text = "بعد از شروع، بازی را باز کن. اول یک بار دکمه CAL را بزن و ۸ نقطه را لمس کن.\n" +
                "دکمه 1-7 / 9-15 / ALL نوع توپ تو را عوض می‌کند.\n" +
                "داخل مچ، دکمه ▶ را بزن؛ ■ یعنی توقف.\n" +
                "دکمه‌ها را بیرون از میز بگذار (با کشیدن ▶ جابجا می‌شوند)."
        })
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        val ov = Settings.canDrawOverlays(this)
        val ac = BotAccessibility.inst != null
        status.text = "نمایش روی برنامه‌ها: ${if (ov) "✔" else "✘"}\nسرویس دسترسی‌پذیری: ${if (ac) "✔" else "✘"}"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
