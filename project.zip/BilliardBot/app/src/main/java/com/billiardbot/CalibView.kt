package com.billiardbot

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class CalibView(ctx: Context, private val frame: Frame, private val cal: Calib, private val onDone: () -> Unit) : View(ctx) {
    private val bmp = Bitmap.createBitmap(frame.px, 0, frame.stride, frame.w, frame.h, Bitmap.Config.ARGB_8888)
    private val pts = ArrayList<PointF>()
    private var verify: List<Ball>? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prompts = listOf(
        "گوشه بالا-چپِ پارچه میز را لمس کن\n(داخل لبه‌ها)",
        "گوشه پایین-راستِ پارچه میز را لمس کن",
        "بالای نوار قدرت را لمس کن\n(جایی که کشیدن شروع می‌شود)",
        "پایین نوار قدرت را لمس کن",
        "دکمه Fine Aim بالا را لمس کن",
        "دکمه Fine Aim پایین را لمس کن",
        "مرکز توپ سفید را لمس کن",
        "لبه توپ سفید را لمس کن"
    )

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawBitmap(bmp, null, RectF(0f, 0f, w, h), null)
        c.save(); c.scale(w / frame.w, h / frame.h)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        for (pt in pts) { p.color = Color.RED; c.drawCircle(pt.x, pt.y, 14f, p); c.drawLine(pt.x - 20, pt.y, pt.x + 20, pt.y, p); c.drawLine(pt.x, pt.y - 20, pt.x, pt.y + 20, p) }
        if (pts.size >= 2) { p.color = Color.GREEN; c.drawRect(min(pts[0].x, pts[1].x), min(pts[0].y, pts[1].y), max(pts[0].x, pts[1].x), max(pts[0].y, pts[1].y), p) }
        if (pts.size >= 4) { p.color = Color.YELLOW; c.drawLine(pts[2].x, pts[2].y, pts[3].x, pts[3].y, p) }
        verify?.let { bl ->
            val names = listOf("W", "S", "T", "8")
            val cols = listOf(Color.WHITE, Color.CYAN, Color.MAGENTA, Color.YELLOW)
            p.textSize = cal.ball * 1.2f; p.style = Paint.Style.STROKE
            for (b in bl) { p.color = cols[b.kind]; p.strokeWidth = 4f; c.drawCircle(b.x, b.y, cal.ball, p)
                p.style = Paint.Style.FILL; c.drawText(names[b.kind], b.x - cal.ball * 0.4f, b.y - cal.ball * 1.2f, p); p.style = Paint.Style.STROKE }
        }
        c.restore()

        val bar = h * 0.11f
        p.style = Paint.Style.FILL; p.color = 0xE6000000.toInt(); c.drawRect(0f, 0f, w, bar, p)
        p.color = 0xFF37474F.toInt(); c.drawRect(w * 0.68f, 0f, w, bar / 2, p)
        p.color = 0xFF8E2424.toInt(); c.drawRect(w * 0.68f, bar / 2, w, bar, p)
        p.color = Color.WHITE; p.textSize = w * 0.035f
        c.drawText("برگشت", w * 0.76f, bar * 0.35f, p)
        c.drawText("لغو", w * 0.80f, bar * 0.85f, p)
        val msg = if (verify != null) "توپ‌ها: ${verify!!.size}  (W سفید، S ساده، T راه‌راه، 8)\nدرست بود؟ هرجا لمس کن تا ذخیره شود.\nغلط بود؟ دوباره با دکمه تنظیم شروع کن."
        else prompts[pts.size]
        var y = bar * 0.25f
        for (line in msg.split("\n")) { c.drawText(line, w * 0.02f, y, p); y += p.textSize * 1.3f }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val w = width.toFloat(); val h = height.toFloat(); val bar = h * 0.11f
        if (e.y < bar) {
            if (e.x > w * 0.68f) { if (e.y < bar / 2) { if (verify == null && pts.isNotEmpty()) pts.removeAt(pts.size - 1) else if (verify != null) { verify = null; pts.removeAt(pts.size - 1) } } else onDone() }
            invalidate(); return true
        }
        if (verify != null) { onDone(); return true }
        pts.add(PointF(e.x * frame.w / w, e.y * frame.h / h))
        if (pts.size == 8) apply()
        invalidate()
        return true
    }

    private fun apply() {
        cal.l = min(pts[0].x, pts[1].x); cal.r = max(pts[0].x, pts[1].x)
        cal.t = min(pts[0].y, pts[1].y); cal.b = max(pts[0].y, pts[1].y)
        cal.pTopX = pts[2].x; cal.pTopY = pts[2].y; cal.pBotX = pts[3].x; cal.pBotY = pts[3].y
        cal.fuX = pts[4].x; cal.fuY = pts[4].y; cal.fdX = pts[5].x; cal.fdY = pts[5].y
        cal.ball = hypot(pts[7].x - pts[6].x, pts[7].y - pts[6].y)
        cal.save()
        verify = Vision.detect(frame, cal)
    }
}
