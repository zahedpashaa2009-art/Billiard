package com.billiardbot

import kotlin.math.hypot

data class P(val x: Float, val y: Float) {
    operator fun plus(o: P) = P(x + o.x, y + o.y)
    operator fun minus(o: P) = P(x - o.x, y - o.y)
    operator fun times(k: Float) = P(x * k, y * k)
    fun len() = hypot(x, y)
    fun norm(): P { val l = len(); return if (l < 1e-6f) P(0f, 0f) else P(x / l, y / l) }
    fun dot(o: P) = x * o.x + y * o.y
}

/** kind: 0 = cue, 1 = solid, 2 = stripe, 3 = eight */
data class Ball(val x: Float, val y: Float, val kind: Int) {
    val p: P get() = P(x, y)
}

class Frame(val w: Int, val h: Int, val stride: Int, val px: IntArray) {
    fun at(x: Int, y: Int) = px[y * stride + x]
}

class Shot(val angle: Float, val power: Float, val note: String)
