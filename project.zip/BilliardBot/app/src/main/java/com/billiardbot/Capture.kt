package com.billiardbot

import android.graphics.Bitmap
import android.media.Image
import android.media.ImageReader

class Capture {
    private val lock = Any()
    private var pending: Image? = null
    private var last: Frame? = null

    fun onImage(r: ImageReader) {
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        synchronized(lock) { pending?.close(); pending = img }
    }

    fun grab(): Frame? = synchronized(lock) {
        val p = pending
        if (p != null) { last = convert(p); p.close(); pending = null }
        last
    }

    fun close() = synchronized(lock) { pending?.close(); pending = null }

    private fun convert(img: Image): Frame {
        val pl = img.planes[0]
        val bw = pl.rowStride / pl.pixelStride
        val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(pl.buffer)
        val arr = IntArray(bw * img.height)
        bmp.getPixels(arr, 0, bw, 0, 0, bw, img.height)
        bmp.recycle()
        for (i in arr.indices) arr[i] = arr[i] or (0xFF shl 24)
        return Frame(img.width, img.height, bw, arr)
    }
}
