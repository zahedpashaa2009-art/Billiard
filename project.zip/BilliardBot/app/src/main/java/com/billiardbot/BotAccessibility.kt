package com.billiardbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class BotAccessibility : AccessibilityService() {
    companion object { @Volatile var inst: BotAccessibility? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Blocking. Call from a background thread. */
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        val path = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur.coerceAtLeast(1))).build()
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        Handler(Looper.getMainLooper()).post {
            val sent = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok.set(true); latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)
            if (!sent) latch.countDown()
        }
        latch.await(dur + 2000, TimeUnit.MILLISECONDS)
        return ok.get()
    }

    fun tap(x: Float, y: Float) = swipe(x, y, x, y, 40)
}
