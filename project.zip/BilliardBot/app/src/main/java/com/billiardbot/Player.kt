package com.billiardbot

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

class Player(private val svc: OverlayService, private val cal: Calib, private val say: (String) -> Unit) {
    @Volatile var running = false
    private var th: Thread? = null
    private var degPerPx = 0.0
    private var degPerTap = 0.0

    fun start() {
        if (running) return
        running = true
        th = Thread {
            try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { say("خطا: ${e.message}") }
            running = false
            svc.onPlayerStopped()
        }.also { it.start() }
    }

    fun stop() { running = false; th?.interrupt() }

    private fun wrap(d: Double): Double { var x = d; while (x > 180) x -= 360; while (x < -180) x += 360; return x }
    private fun deg(r: Float) = Math.toDegrees(r.toDouble())

    private fun loop() {
        while (running) {
            val f1 = svc.capture.grab()
            if (f1 == null) { Thread.sleep(300); continue }
            val b1 = Vision.detect(f1, cal)
            val c1 = b1.firstOrNull { it.kind == 0 }
            if (c1 == null) { say("منتظر توپ سفید…"); Thread.sleep(700); continue }
            Thread.sleep(250)
            val f2 = svc.capture.grab() ?: continue
            val b2 = Vision.detect(f2, cal)
            val c2 = b2.firstOrNull { it.kind == 0 }
            if (c2 == null || hypot(c1.x - c2.x, c1.y - c2.y) > 1.5f || b1.size != b2.size) { Thread.sleep(300); continue }
            if (Vision.aimAngle(f2, c2, cal.ball, null) == null) { say("منتظر نوبت تو…"); Thread.sleep(700); continue }

            val geo = Geo(cal.l, cal.t, cal.r, cal.b, cal.ball)
            val shot = Planner.plan(c2, b2, cal.mode, geo, cal.powerScale)
            if (shot == null) { Thread.sleep(700); continue }
            say(shot.note)
            if (!aim(shot.angle, c2)) { say("تنظیم زاویه ناموفق بود"); Thread.sleep(800); continue }
            if (!power(shot.power)) { say("کشیدن قدرت ناموفق بود"); break }
            Thread.sleep(3000)
            waitStable()
        }
    }

    private fun waitStable() {
        var prev = Double.NaN; var same = 0
        for (i in 0 until 40) {
            if (!running) return
            Thread.sleep(400)
            val f = svc.capture.grab() ?: continue
            val bl = Vision.detect(f, cal)
            val sig = bl.sumOf { (it.x + it.y).toDouble() } + bl.size * 10000.0
            if (!prev.isNaN() && abs(sig - prev) < 2.0) same++ else same = 0
            prev = sig
            if (same >= 2) return
        }
    }

    private fun aim(target: Float, cue: Ball): Boolean {
        val acc = BotAccessibility.inst ?: return false
        val tDeg = deg(target)
        for (i in 0 until 10) {
            if (!running) return false
            Thread.sleep(150)
            val f = svc.capture.grab() ?: return false
            val cur = Vision.aimAngle(f, cue, cal.ball, target) ?: return false
            val err = wrap(tDeg - deg(cur))
            if (abs(err) < 0.1) return true
            if (abs(err) > 0.7) {
                val mx = (cal.l + cal.r) / 2; val y = cal.b - (cal.b - cal.t) * 0.1f
                if (degPerPx == 0.0) {
                    acc.swipe(mx - 20, y, mx + 20, y, 250); Thread.sleep(350)
                    val a2 = Vision.aimAngle(svc.capture.grab() ?: return false, cue, cal.ball, target) ?: return false
                    val d = wrap(deg(a2) - deg(cur))
                    if (abs(d) < 0.02) { say("کشیدن روی میز زاویه را عوض نکرد"); return false }
                    degPerPx = d / 40.0
                } else {
                    val dx = (err / degPerPx).coerceIn(-250.0, 250.0)
                    acc.swipe((mx - dx / 2).toFloat(), y, (mx + dx / 2).toFloat(), y, 250)
                }
            } else {
                if (degPerTap == 0.0) {
                    acc.tap(cal.fuX, cal.fuY); Thread.sleep(300)
                    val a2 = Vision.aimAngle(svc.capture.grab() ?: return false, cue, cal.ball, target) ?: return false
                    val d = wrap(deg(a2) - deg(cur))
                    if (abs(d) < 0.003) { say("Fine Aim زاویه را عوض نکرد"); return false }
                    degPerTap = d
                } else {
                    val raw = err / degPerTap
                    var n = raw.roundToInt().coerceIn(-25, 25)
                    if (n == 0) n = if (raw > 0) 1 else -1
                    val x = if (n > 0) cal.fuX else cal.fdX
                    val yy = if (n > 0) cal.fuY else cal.fdY
                    repeat(abs(n)) { acc.tap(x, yy); Thread.sleep(80) }
                }
            }
            Thread.sleep(300)
        }
        return false
    }

    private fun power(p: Float): Boolean {
        val acc = BotAccessibility.inst ?: return false
        val x2 = cal.pTopX + (cal.pBotX - cal.pTopX) * p
        val y2 = cal.pTopY + (cal.pBotY - cal.pTopY) * p
        return acc.swipe(cal.pTopX, cal.pTopY, x2, y2, 700)
    }
}
