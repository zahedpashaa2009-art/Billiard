package com.billiardbot

import kotlin.math.*

object Vision {
    private fun white(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return min(r, min(g, b)) > 175 && max(r, max(g, b)) - min(r, min(g, b)) < 50
    }

    private fun aimWhite(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return min(r, min(g, b)) > 190 && max(r, max(g, b)) - min(r, min(g, b)) < 45
    }

    private fun disk(rad: Float, step: Int): IntArray {
        val l = ArrayList<Int>()
        val ri = rad.toInt()
        var dy = -ri
        while (dy <= ri) {
            var dx = -ri
            while (dx <= ri) {
                if (dx * dx + dy * dy <= rad * rad) { l.add(dx); l.add(dy) }
                dx += step
            }
            dy += step
        }
        return l.toIntArray()
    }

    fun detect(f: Frame, c: Calib): List<Ball> {
        val r = c.ball
        val x0 = max(0, c.l.toInt()); val y0 = max(0, c.t.toInt())
        val x1 = min(f.w - 1, c.r.toInt()); val y1 = min(f.h - 1, c.b.toInt())
        val W = x1 - x0 + 1; val H = y1 - y0 + 1
        if (W < 60 || H < 60 || r < 4f) return emptyList()

        // cloth colour = per-channel median of a coarse grid
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        var yy = 0
        while (yy < H) {
            var xx = 0
            while (xx < W) {
                val p = f.at(x0 + xx, y0 + yy)
                rs.add((p shr 16) and 255); gs.add((p shr 8) and 255); bs.add(p and 255)
                xx += 17
            }
            yy += 17
        }
        rs.sort(); gs.sort(); bs.sort()
        val cr = rs[rs.size / 2]; val cg = gs[gs.size / 2]; val cb = bs[bs.size / 2]

        // mask: bit0 = differs from cloth, bit1 = white
        val m = ByteArray(W * H)
        for (y in 0 until H) {
            val row = (y0 + y) * f.stride + x0
            for (x in 0 until W) {
                val p = f.px[row + x]
                val dr = ((p shr 16) and 255) - cr; val dg = ((p shr 8) and 255) - cg; val db = (p and 255) - cb
                var v = 0
                if (dr * dr + dg * dg + db * db > 3025) v = 1
                if (white(p)) v = v or 3
                m[y * W + x] = v.toByte()
            }
        }
        fun mk(x: Int, y: Int): Int = if (x < 0 || y < 0 || x >= W || y >= H) 0 else m[y * W + x].toInt()

        val wc = disk(r * 0.35f, 2)
        val fl = disk(r * 0.8f, 2)
        val cands = ArrayList<FloatArray>()
        val mar = (r * 0.8f).toInt() + 1
        var cy = mar
        while (cy < H - mar) {
            var cx = mar
            while (cx < W - mar) {
                var w = 0; var i = 0
                while (i < wc.size) { if ((mk(cx + wc[i], cy + wc[i + 1]) and 2) != 0) w++; i += 2 }
                val wf = w.toFloat() / (wc.size / 2)
                if (wf >= 0.6f) {
                    var fc = 0; i = 0
                    while (i < fl.size) { if ((mk(cx + fl[i], cy + fl[i + 1]) and 1) != 0) fc++; i += 2 }
                    val ff = fc.toFloat() / (fl.size / 2)
                    if (ff >= 0.88f) cands.add(floatArrayOf(cx.toFloat(), cy.toFloat(), ff + wf))
                }
                cx += 3
            }
            cy += 3
        }
        cands.sortByDescending { it[2] }
        val acc = ArrayList<FloatArray>()
        for (cd in cands) {
            if (acc.none { hypot(it[0] - cd[0], it[1] - cd[1]) < 1.5f * r }) acc.add(cd)
            if (acc.size > 20) break
        }

        // refine centre: centroid of the best-fill plateau
        val big = disk(r * 0.95f, 2)
        val refined = ArrayList<FloatArray>()
        for (a in acc) {
            val sx = a[0].toInt(); val sy = a[1].toInt()
            val fills = FloatArray(121)
            var best = -1f
            for (oy in -5..5) for (ox in -5..5) {
                var fc = 0; var i = 0
                while (i < big.size) { if ((mk(sx + ox + big[i], sy + oy + big[i + 1]) and 1) != 0) fc++; i += 2 }
                val v = fc.toFloat() / (big.size / 2)
                fills[(oy + 5) * 11 + ox + 5] = v
                if (v > best) best = v
            }
            var mx = 0f; var my = 0f; var n = 0
            for (oy in -5..5) for (ox in -5..5) if (fills[(oy + 5) * 11 + ox + 5] >= best - 0.02f) { mx += ox; my += oy; n++ }
            refined.add(floatArrayOf(x0 + sx + mx / n, y0 + sy + my / n))
        }
        val uniq = ArrayList<FloatArray>()
        for (a in refined) if (uniq.none { hypot(it[0] - a[0], it[1] - a[1]) < 1.2f * r }) uniq.add(a)

        val off = disk(r * 0.85f, 1)
        val out = ArrayList<Ball>()
        var cue: Ball? = null; var cueWf = 0f
        for (a in uniq) {
            val (kind, wf) = classify(f, a[0], a[1], off)
            if (kind == 0) { if (wf > cueWf) { cueWf = wf; cue = Ball(a[0], a[1], 0) } }
            else out.add(Ball(a[0], a[1], kind))
        }
        if (cue != null) out.add(0, cue)
        return out
    }

    private fun classify(f: Frame, cx: Float, cy: Float, off: IntArray): Pair<Int, Float> {
        var tot = 0; var wh = 0; var darkSum = 0L; var nw = 0
        var i = 0
        while (i < off.size) {
            val x = (cx + off[i]).roundToInt(); val y = (cy + off[i + 1]).roundToInt()
            i += 2
            if (x < 0 || y < 0 || x >= f.w || y >= f.h) continue
            val p = f.at(x, y); tot++
            if (white(p)) wh++ else {
                darkSum += max(max((p shr 16) and 255, (p shr 8) and 255), p and 255); nw++
            }
        }
        val wf = if (tot == 0) 0f else wh / tot.toFloat()
        val avgMax = if (nw == 0) 255f else darkSum.toFloat() / nw
        val kind = when {
            wf > 0.7f -> 0
            avgMax < 85f && wf < 0.5f -> 3
            wf > 0.27f -> 2
            else -> 1
        }
        return Pair(kind, wf)
    }

    /** Reads the angle (radians, screen coords) of the game's white aim line. null if not visible. */
    fun aimAngle(f: Frame, cue: Ball, r: Float, hint: Float?): Float? {
        val d0 = r * 2.4f; val len = 230
        val n = 1440
        val score = FloatArray(n)
        for (k in 0 until n) {
            val th = k * (2.0 * PI / n)
            val cs = cos(th); val sn = sin(th)
            var hit = 0; var cnt = 0
            var d = d0.toDouble()
            while (d < d0 + len) {
                val x = (cue.x + d * cs).roundToInt(); val y = (cue.y + d * sn).roundToInt()
                if (x in 0 until f.w && y in 0 until f.h) { cnt++; if (aimWhite(f.at(x, y))) hit++ }
                d += 2.0
            }
            score[k] = if (cnt > 0) hit.toFloat() / cnt else 0f
        }
        var bk = 0
        for (k in 0 until n) if (score[k] > score[bk]) bk = k
        if (score[bk] < 0.6f) return null
        // the cue stick lies on the opposite side: pick the peak nearer the hint if both are strong
        val ok = (bk + n / 2) % n
        if (hint != null && score[ok] >= 0.6f * score[bk]) {
            val a1 = bk * 2.0 * PI / n; val a2 = ok * 2.0 * PI / n
            fun diff(a: Double): Double { var d = a - hint; while (d > PI) d -= 2 * PI; while (d < -PI) d += 2 * PI; return abs(d) }
            if (diff(a2) < diff(a1)) bk = ok
        }
        val th0 = bk * 2.0 * PI / n
        val cs = cos(th0); val sn = sin(th0)
        var sw = 0.0; var sa = 0.0
        var d = d0.toDouble()
        while (d < d0 + len) {
            for (o in -5..5) {
                val x = (cue.x + d * cs - o * sn).roundToInt(); val y = (cue.y + d * sn + o * cs).roundToInt()
                if (x in 0 until f.w && y in 0 until f.h && aimWhite(f.at(x, y))) {
                    var da = atan2(y - cue.y.toDouble(), x - cue.x.toDouble()) - th0
                    while (da > PI) da -= 2 * PI; while (da < -PI) da += 2 * PI
                    sa += da * d * d; sw += d * d
                }
            }
            d += 1.0
        }
        return (if (sw > 0) th0 + sa / sw else th0).toFloat()
    }
}
